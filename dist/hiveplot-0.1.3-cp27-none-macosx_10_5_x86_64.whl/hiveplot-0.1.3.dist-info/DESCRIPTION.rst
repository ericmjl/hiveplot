This is a module that will allow you to easily make hive plots from network data.

More information can be found at the Github repository.

