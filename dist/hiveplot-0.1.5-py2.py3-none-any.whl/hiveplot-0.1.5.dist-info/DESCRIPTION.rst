A utility for making hive plots in matplotlib.


