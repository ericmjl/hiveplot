Utility class for easily making hive plots in Python.


